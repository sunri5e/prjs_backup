$(document).ready(function(){
  $('#headerMenuTriger').on('click', function(){
    $('.pb-top-nav').toggleClass('is-open');
  });
});